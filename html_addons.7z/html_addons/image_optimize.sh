#!/bin/bash
find -iname *.png > tmp
sed -i "s/\.\///" tmp;
while read line
do
echo $line;
advdef -z -4 "$line";
advpng -z -4 "$line";
#wine deflopt.exe "$line";
./defluff <"$line" > "$line-1";
mv "$line-1" "$line";
done < tmp


find -iname *.jpg > tmp;
find -iname *.jpeg >> tmp;
sed -i "s/\.\///" tmp;
while read line
do
echo $line;
#imgmin "$line" "$line-1";
jpegtran -optimize -progressive "$line" > "$line-1";
mv "$line-1" "$line";
done < tmp
