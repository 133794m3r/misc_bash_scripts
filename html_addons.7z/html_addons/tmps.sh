#!/bin/bash
find -iname *.html > tmp;
find -iname *.xml >> tmp;
find -iname *.xhtml >> tmp;
find -iname *.opf >> tmp;
find -iname *.ncx >> tmp;
find -iname *.xpgt >> tmp;
find -iname *.xhtml >> tmp;
sed -i "s/\.\///" tmp;
FILENAME=tmp;
while read line
do
echo $line;
java -jar htmlcompressor.jar --remove-intertag-spaces --remove-style-attr --remove-link-attr --simple-bool-attr  --remove-surrounding-spaces all "$line" -o "$line-1"
#java -jar yuicompressor.jar "$line" -o "$line-1";
mv "$line-1" "$line";
done < tmp
